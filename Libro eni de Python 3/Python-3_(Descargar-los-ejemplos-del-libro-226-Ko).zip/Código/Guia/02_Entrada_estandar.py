"""
Demostración del uso de la entrada estándar

El programa pide información y la muestra a continuación
"""

# Se pide la información
informacion = input("Introduzca alguna información: ")

# Se muestra esta información (varias visualizaciones, separadas por " ")
print("Ha introducido: ", informacion)

