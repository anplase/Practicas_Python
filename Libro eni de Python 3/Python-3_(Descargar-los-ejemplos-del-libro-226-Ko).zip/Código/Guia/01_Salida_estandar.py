"""
Demostración del uso de la salida estándar

El ejemplo más básico de programa en Python.
"""

print("Hello World!")

